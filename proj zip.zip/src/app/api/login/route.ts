// import { NextResponse } from 'next/server';
// import prisma from '@/lib/prisma';
// import bcrypt from 'bcryptjs';

// // Force dynamic rendering
// export const dynamic = 'force-dynamic';

// export async function POST(request: Request) {
//   try {
//     const { email, password } = await request.json()
//     const normalizedEmail = (email || '').trim().toLowerCase()

//     // Validate input
//     if (!email || !password) {
//       return NextResponse.json(
//         { error: 'Email and password are required' },
//         { status: 400 }
//       )
//     }

//     // Check if user exists
//     const user = await prisma.user.findUnique({
//       where: { email: normalizedEmail },
//       select: {
//         id: true,
//         name: true,
//         email: true,
//         phone: true,
//         dob: true,
//         address: true,
//         role: true,
//         createdAt: true
//       }
//     })

//     if (!user) {
//       return NextResponse.json(
//         { error: 'Account not found' },
//         { status: 404 }
//       )
//     }

//     // Get the full user record for password verification
//     const fullUser = await prisma.user.findUnique({
//       where: { email: normalizedEmail }
//     })

//     if (!fullUser) {
//       return NextResponse.json(
//         { error: 'Account not found' },
//         { status: 404 }
//       )
//     }

//     // Verify password
//     const isValid = await bcrypt.compare(password, fullUser.password)
//     if (!isValid) {
//       return NextResponse.json(
//         { error: 'Invalid password' },
//         { status: 401 }
//       )
//     }

//     console.log('Login successful, returning user data:', user)
//     return NextResponse.json(user, { status: 200 })

//   } catch (error: any) {
//     console.error('Login error:', error)
//     return NextResponse.json(
//       { error: error.message || 'Internal server error' },
//       { status: 500 }
//     )
//   }
// } 

import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import bcrypt from 'bcryptjs';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password are required' }, { status: 400 })
    }

    const normalizedEmail = (email as string).trim().toLowerCase()

    // FIX: was two separate DB queries — combined into one
    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        dob: true,
        address: true,
        role: true,
        createdAt: true,
        password: true,   // needed for comparison
      }
    })

    if (!user) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 })
    }

    const isValid = await bcrypt.compare(password, user.password)
    if (!isValid) {
      return NextResponse.json({ error: 'Invalid password' }, { status: 401 })
    }

    // Strip password before returning
    const { password: _pw, ...safeUser } = user
    return NextResponse.json(safeUser, { status: 200 })

  } catch (error: any) {
    console.error('Login error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}